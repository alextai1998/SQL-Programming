CREATE FUNCTION camelcase (a text, b text) RETURNS text
	LANGUAGE plpgsql
AS $$
BEGIN
  RETURN CONCAT(INITCAP(a), 'dr', INITCAP(b));
END;
$$
