CREATE FUNCTION fibo (num_terms integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
  BEGIN
    IF num_terms < 2 THEN
      RETURN num_terms;
    ELSE
      RETURN fibo(num_terms-2) + fibo(num_terms-1);
    END IF;
  END;
  
$$
