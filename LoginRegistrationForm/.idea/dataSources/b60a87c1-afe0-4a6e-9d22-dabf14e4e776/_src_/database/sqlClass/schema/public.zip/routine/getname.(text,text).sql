CREATE FUNCTION getname (fname text, email text, OUT dmn text, OUT lastname text, OUT firstname text) RETURNS record
	LANGUAGE plpgsql
AS $$
BEGIN
  firstname := fname;
  dmn = split_part(email, '@', 2);
  lastname = INITCAP(split_part(split_part(email,'.', 2),'@' ,1));
END;
$$
