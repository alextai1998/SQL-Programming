CREATE FUNCTION ave_total (VARIADIC inputs numeric[], OUT total integer, OUT average double precision) RETURNS record
	LANGUAGE plpgsql
AS $$
DECLARE
  r INTEGER;
  num INTEGER;
BEGIN
  total := 0;
  average := 0;
  num := 0;
  FOR r IN SELECT unnest(inputs)
  LOOP
    total := total + r;
    num := num + 1;
  END LOOP;
  average := total / num;
END;
$$
