CREATE FUNCTION meanvalue (id integer, date date, VARIADIC inputs numeric[]) RETURNS integer
	LANGUAGE plpgsql
AS $$
DECLARE
  sum INTEGER; -- sum of all numbers
  cnt INTEGER; -- counter of numbers
  num INTEGER; -- each number
BEGIN
  cnt := 0;
  sum := 0;
  FOR num IN SELECT unnest(inputs)
    LOOP
    cnt := cnt + 1;
    sum := sum + num;
  END LOOP;
  RAISE NOTICE 'The id is %, the date is %, average is %', id, date, sum/cnt;
  RETURN sum/cnt;
END;
$$
