CREATE FUNCTION insertmulgrades (id integer, date date, VARIADIC inputs numeric[]) RETURNS void
	LANGUAGE plpgsql
AS $$
  DECLARE
    sum INTEGER; -- sum of all numbers
    cnt INTEGER; -- counter of numbers
    grade INTEGER; -- each number
  BEGIN
    cnt := 0;
    sum := 0;
    FOR grade IN SELECT unnest(inputs)
      LOOP
        INSERT INTO grades(student_id, score, scoreLetter, date) VALUES (id, grade, getLetter(grade), date);
      END LOOP;
    RAISE NOTICE 'The id is %, the date is %', id, date;
  END;
  
$$
