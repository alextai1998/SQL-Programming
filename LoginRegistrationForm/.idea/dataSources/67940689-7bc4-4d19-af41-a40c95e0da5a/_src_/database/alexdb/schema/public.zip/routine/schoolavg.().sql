CREATE FUNCTION schoolavg () RETURNS TABLE(score character varying)
	LANGUAGE plpgsql
AS $$
DECLARE
  sum INTEGER := 0; -- sum of all numbers
  cnt INTEGER := 0; -- counter of numbers
  grade INTEGER := 0; -- each number
  fname VARCHAR(30); -- student first name
  lname VARCHAR(30); -- student last name
BEGIN
  FOR grade in SELECT grades.score FROM grades
  LOOP
    sum := sum + grade;
    cnt := cnt + 1;
  END LOOP;

  score := getLetter(sum/cnt);

  RETURN NEXT;
END;
$$
