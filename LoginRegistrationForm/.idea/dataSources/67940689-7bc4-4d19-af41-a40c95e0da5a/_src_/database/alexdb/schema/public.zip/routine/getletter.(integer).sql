CREATE FUNCTION getletter (grades integer) RETURNS character varying
	LANGUAGE plpgsql
AS $$
  BEGIN
    IF 100 >= grades AND grades >= 90 THEN
      RETURN 'A';
    ELSEIF 89 >= grades AND grades >= 80 THEN
      RETURN 'B';
    ELSEIF 79 >= grades AND grades >= 70 THEN
      RETURN 'C';
    ELSEIF 69 >= grades AND grades >= 60 THEN
      RETURN 'D';
    ELSEIF 59 >= grades AND grades >= 0 THEN
      RETURN 'F';
    ELSE
      RETURN 'Invalid Number';
    END IF;
  END;
  
$$
