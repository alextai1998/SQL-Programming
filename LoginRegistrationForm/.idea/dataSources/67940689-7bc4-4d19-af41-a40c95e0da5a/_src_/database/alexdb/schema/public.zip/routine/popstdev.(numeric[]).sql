CREATE FUNCTION popstdev (VARIADIC inputs numeric[]) RETURNS TABLE(std character varying, popmean numeric)
	LANGUAGE plpgsql
AS $$
DECLARE
  sum DECIMAL := 0; -- sum of all numbers
  sum2 DECIMAL := 0; -- sum of all grades subtract mean
  diffsqrd DECIMAL := 0; -- sum of all numbers
  popMean DECIMAL := 0; -- sum of all numbers
  cnt DECIMAL := 0; -- counter of numbers
  cnt2 DECIMAL := 0; -- 2nd counter of numbers
  num DECIMAL := 0; -- each number
BEGIN
  FOR num IN SELECT unnest(inputs)
  LOOP
    sum := sum + num;
    cnt := cnt + 1;
  END LOOP;

  popMean := sum/cnt;

  FOR num IN SELECT unnest(inputs)
  LOOP
    diffsqrd := (num - popMean)^2;
    sum2 := sum2 + diffsqrd;
    cnt2 := cnt2 + 1;
  END LOOP;

  std := |/(sum2/cnt2);

  RETURN NEXT;
END;
$$
