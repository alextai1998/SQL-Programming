CREATE FUNCTION popstdev (id integer, dte date) RETURNS TABLE(std character varying, sname character varying, popmean numeric)
	LANGUAGE plpgsql
AS $$
DECLARE
  sum DECIMAL := 0; -- sum of all numbers
  sum2 DECIMAL := 0; -- sum of all grades subtract mean
  diff DECIMAL := 0; -- sum of all numbers
  mean DECIMAL := 0; -- sum of all numbers
  cnt DECIMAL := 0; -- counter of numbers
  cnt2 DECIMAL := 0; -- 2nd counter of numbers
  grade DECIMAL := 0; -- each number
  fname VARCHAR(30); -- student first name
  lname VARCHAR(30); -- student last name
BEGIN
  FOR grade in SELECT grades.score FROM grades WHERE grades.date <= dte AND student_id = id
  LOOP
    sum := sum + grade;
    cnt := cnt + 1;
  END LOOP;

  SELECT firstname INTO fname FROM students WHERE student_id = id;
  SELECT lastname INTO lname FROM students WHERE student_id = id;

  popMean := sum/cnt;

  FOR grade in SELECT grades.score FROM grades WHERE grades.date <= dte AND student_id = id
  LOOP
    diff := (grade - popMean)^2;
    sum2 := sum2 + diff;
    cnt2 := cnt2 + 1;
  END LOOP;

  sName := CONCAT(fname, ' ', lname);
  std := |/(sum2/cnt2);

  RETURN NEXT;
END;
$$
