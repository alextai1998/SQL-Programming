CREATE FUNCTION award_insertion () RETURNS trigger
	LANGUAGE plpgsql
AS $$
DECLARE id_series INTEGER;
DECLARE id_award INTEGER;
BEGIN
  IF NOT EXISTS (SELECT award_id FROM award WHERE category = NEW.category AND organize = NEW.organize)
  THEN
    INSERT INTO award (category, organize)
      VALUES (NEW.category, NEW.organize);
  END IF;

  IF NOT EXISTS (SELECT tv_series_id FROM tv_series WHERE title_series = NEW.title_series)
  THEN
    INSERT INTO tv_series (title_series, year, language, budget)
      VALUES (NEW.title_series, NEW.year, NEW.language, NEW.budget);
  END IF;

  id_series:= 0;
  id_award:= 0;
  SELECT award_id INTO id_award FROM award WHERE category = NEW.category AND organize = NEW.organize;
  SELECT tv_series_id INTO id_series FROM tv_series WHERE title_series = NEW.title_series;

  INSERT INTO awards_tvseries (award_id, tv_series_id)
    VALUES (id_award, id_series);
  RETURN NEW;
END;
$$
