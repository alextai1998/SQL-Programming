CREATE FUNCTION product (a integer, b integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
  BEGIN
   RETURN a * b;
  END;
  
$$
