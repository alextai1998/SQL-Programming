CREATE FUNCTION email (firstname text, lastname text, dmn text DEFAULT '@pas.org'::text) RETURNS text
	LANGUAGE plpgsql
AS $$
BEGIN
    RETURN CONCAT(LOWER(SUBSTRING(firstname, 1, 1)), '.',  LOWER(lastname), dmn);
END;
$$
