CREATE FUNCTION actor_insertion () RETURNS trigger
	LANGUAGE plpgsql
AS $$
DECLARE id_series INTEGER;
DECLARE id_actor INTEGER;
BEGIN
  IF NOT EXISTS (SELECT actor_id FROM actor WHERE firstName = NEW.firstName AND lastName = NEW.lastName)
  THEN
    INSERT INTO actor (firstName, lastName, nationality)
     VALUES (NEW.firstName, NEW.lastName, NEW.nationality);
  END IF;

  IF NOT EXISTS (SELECT tv_series_id FROM tv_series WHERE title_series = NEW.title_series)
  THEN
    INSERT INTO tv_series (title_series, year, language, budget)
      VALUES (NEW.title_series, NEW.year, NEW.language, NEW.budget);
  END IF;

  id_series:= 0;
  id_actor:= 0;
  SELECT actor_id INTO id_actor FROM actor WHERE firstName = NEW.firstName AND lastName = NEW.lastName;
  SELECT tv_series_id INTO id_series FROM tv_series WHERE title_series = NEW.title_series;

  INSERT INTO starrIn (actor_id, tv_series_id)
    VALUES (id_actor, id_series);
  RETURN NEW;
END;
$$
