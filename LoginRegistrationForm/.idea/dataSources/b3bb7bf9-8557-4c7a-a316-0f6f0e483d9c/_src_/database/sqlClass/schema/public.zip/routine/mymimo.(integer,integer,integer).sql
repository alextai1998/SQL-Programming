CREATE FUNCTION mymimo (a integer, b integer, c integer, OUT total integer, OUT maxi integer) RETURNS record
	LANGUAGE plpgsql
AS $$
BEGIN
  total := a + b + c;
  maxi := GREATEST(a, b, c);
END;
$$
