CREATE FUNCTION fillform () RETURNS trigger
	LANGUAGE plpgsql
AS $$
DECLARE id_series INTEGER;
DECLARE id_network INTEGER;
BEGIN
  IF NOT EXISTS (SELECT network_id FROM network WHERE name_network = NEW.name_network)
  THEN
    INSERT INTO network (name_network, location)
    VALUES (NEW.name_network, NEW.location);
  END IF;

  IF NOT EXISTS (SELECT tv_series_id FROM tv_series WHERE title_series = NEW.title_series)
  THEN
    INSERT INTO tv_series (title_series, year, language, budget)
      VALUES (NEW.title_series, NEW.year, NEW.language, NEW.budget);
  END IF;

  id_series:= 0;
  id_network:= 0;
  SELECT tv_series_id INTO id_series FROM tv_series WHERE
    title_series = NEW.title_series AND year = NEW.year AND budget = NEW.budget AND language = NEW.language;
  SELECT network_id INTO id_network FROM network WHERE name_network = NEW.name_network AND location = NEW.location;

   INSERT INTO featureIn (tv_series_id, network_id)
    VALUES (id_series, id_network);
  RETURN NEW;
END;
$$
