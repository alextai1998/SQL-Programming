CREATE FUNCTION failingnum (VARIADIC inputs numeric[]) RETURNS integer
	LANGUAGE plpgsql
AS $$
DECLARE
  score INTEGER;
  cnt   INTEGER := 0;
BEGIN
  FOR score IN SELECT unnest(inputs)
  LOOP
    IF score < 60
    THEN
      cnt := cnt + 1;
    END IF;
  END LOOP;
  RAISE NOTICE 'The number of failing grades: %', cnt;
  RETURN cnt;
END;
$$
