CREATE FUNCTION randtable (numvalues integer) RETURNS TABLE(number integer)
	LANGUAGE plpgsql
AS $$
BEGIN
  FOR x in 0..numValues LOOP
    number:= trunc(random()*100);
    RETURN NEXT;
  END LOOP;
END;
$$
