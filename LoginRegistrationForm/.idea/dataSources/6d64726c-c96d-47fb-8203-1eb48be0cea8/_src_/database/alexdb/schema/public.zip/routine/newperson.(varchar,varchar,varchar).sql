CREATE FUNCTION newperson (firstname character varying, lastname character varying, role character varying) RETURNS void
	LANGUAGE plpgsql
AS $$
  DECLARE
    str VARCHAR(20);
  BEGIN
    str := CONCAT(LOWER(role), '.pas.org') ;
    INSERT INTO students(firstname,
                         lastname,
                         email,
                         created) VALUES (firstname,
                                          lastname,
                                          setEmail(firstname, lastname, str),
                                          current_date);
  END;
  
$$
